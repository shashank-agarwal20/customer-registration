package com.customerregistration;

import static org.assertj.core.api.Assertions.assertThat;
import static org.junit.Assert.assertTrue;

import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.springframework.boot.test.context.SpringBootTest;

import com.customerRegistration.CustomerRegistrationApplication;

@SpringBootTest
class CustomerRegistrationApplicationTest {

	@InjectMocks
	CustomerRegistrationApplication customerRegistrationApplication;

	@Test
	void contextLoads() {
		assertTrue(true);
	}

	@Test
	void testCustomerRegistrationApplication() {
		assertThat(customerRegistrationApplication).isNull();
	}

}
