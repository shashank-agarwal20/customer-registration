package com.customerregistration.service;

import static org.junit.Assert.*;
import static org.junit.jupiter.api.Assertions.assertEquals;

import org.junit.Test;
import org.junit.jupiter.api.DisplayName;
import org.mockito.InjectMocks;
import org.springframework.boot.test.context.SpringBootTest;

import com.customerRegistration.dto.CustomerProfileDTO;
import com.customerRegistration.service.CustomerProfileServiceImpl;

@SpringBootTest
public class CustomerProfileServiceTests {
	
	@InjectMocks
	CustomerProfileServiceImpl customerProfileServiceImpl = new CustomerProfileServiceImpl();
	
	@Test
	@DisplayName("Checking the method with Invalid Response")
	public void testCreateCustomerProfile_EmptyRequestBody() {

		CustomerProfileDTO customerProfileDTO = new CustomerProfileDTO();
		
		String actual = customerProfileServiceImpl.createCustomerProfile(customerProfileDTO);
		System.out.println(actual);
		String expected = "[{\"name\":\"Name\",\"detail\":\"Name is mandatory or missing\",\"name\":\"Username\",\"detail\":\"Username is mandatory or missing\",\"name\":\"password\",\"detail\":\"Password should contain atleast 6 characters, uppercase, lowercase, special characters and numbers\",\"name\":\"address\",\"detail\":\"Address should be less than 50 characters\",\"name\":\"state\",\"detail\":\"State field is Mandatory\",\"name\":\"country\",\"detail\":\"Country field is Mandatory\",\"name\":\"Email\",\"detail\":\"Enter a Vaild Email Address\",\"name\":\"Pan\",\"detail\":\"Enter a Vaild PAN Number\",\"name\":\"AccountType\",\"detail\":\"Account Type should be Salary or Savings\",\"name\":\"MobileNumber\",\"detail\":\"Mobile number should have 10 digits\",\"name\":\"DOB\",\"detail\":\"DOB is incorrect or missing\"}]";
		
		assertEquals(actual, expected);
	}

}
