package com.customerregistration.controller;

import static org.assertj.core.api.Assertions.assertThat;
import static org.junit.jupiter.api.Assertions.assertEquals;

import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.springframework.boot.test.context.SpringBootTest;

import com.customerRegistration.controller.CustomerProfileController;
import com.customerRegistration.dto.CustomerProfileDTO;
import com.customerRegistration.service.CustomerProfileServiceImpl;

@SpringBootTest
public class CustomerProfileControllerTest2 {

	@InjectMocks
	CustomerProfileServiceImpl customerProfileServiceImpl = new CustomerProfileServiceImpl();
	
	@Test
	@DisplayName("Checking the method with Invalid Response")
	public void testCreateCustomerProfile_EmptyRequestBody() {

		CustomerProfileDTO customerProfileDTO = new CustomerProfileDTO();
		customerProfileDTO.setPassword("Ajita@123");
		customerProfileDTO.setAddress("123 Gurgaon");
		customerProfileDTO.setEmailAddress("ajita@gmail");
		customerProfileDTO.setPan("CHGIR456O");
		customerProfileDTO.setMobileNo("9090909090");
		
		
		String actual = customerProfileServiceImpl.createCustomerProfile(customerProfileDTO);
		System.out.println(actual);
		String expected = "[{\"name\":\"Name\",\"detail\":\"Name is mandatory or missing\"},{\"name\":\"Username\",\"detail\":\"Username is mandatory or missing\"},{\"name\":\"state\",\"detail\":\"State field is Mandatory\"},{\"name\":\"country\",\"detail\":\"Country field is Mandatory\"},{\"name\":\"Pan\",\"detail\":\"Enter a Vaild PAN Number\"},{\"name\":\"AccountType\",\"detail\":\"Account Type should be Salary or Savings\"},{\"name\":\"DOB\",\"detail\":\"DOB is incorrect or missing\"}]";
		
		assertEquals(actual, expected);
	}
	
	

}
