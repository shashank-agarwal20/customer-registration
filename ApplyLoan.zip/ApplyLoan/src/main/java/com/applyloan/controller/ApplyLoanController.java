package com.applyloan.controller;

import java.util.Optional;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.applyloan.dto.ApplyLoanDTO;
import com.applyloan.model.ApplyLoanModel;
import com.applyloan.repository.ApplyLoanRepository;
import com.applyloan.service.ApplyLoanServiceImpl;

@RestController
public class ApplyLoanController {
	private final Logger log = LoggerFactory.getLogger(ApplyLoanController.class);
	@Autowired
	ApplyLoanServiceImpl applyLoanServiceImpl;

	@Autowired
	ApplyLoanRepository applyLoanRepository;

	@PostMapping("/applyLoan")
	public String loanDetails(@RequestBody ApplyLoanDTO applyLoanDTO) {
		String response;
//		String loan = applyLoanRepository.findByUsername(applyLoanDTO.getUserName());
		log.info("apply loan -started");
		response = applyLoanServiceImpl.loanDetails(applyLoanDTO);

		return response;
	}
}
