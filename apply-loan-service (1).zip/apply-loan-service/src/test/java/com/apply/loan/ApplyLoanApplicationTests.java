package com.apply.loan;

import static org.junit.Assert.assertTrue;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ApplyLoanApplicationTests {

	@Test
	void contextLoads() {
		assertTrue(true);
	}

}
