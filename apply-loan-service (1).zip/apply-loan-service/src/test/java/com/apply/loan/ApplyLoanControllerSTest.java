package com.apply.loan;

import static org.junit.Assert.assertEquals;

import org.junit.Test;
import org.mockito.InjectMocks;
import org.springframework.boot.test.context.SpringBootTest;

import com.apply.loan.dto.ApplyLoanDTO;
import com.apply.loan.service.ApplyLoanServiceImpl;

@SpringBootTest
public class ApplyLoanControllerSTest {

	@InjectMocks
    ApplyLoanServiceImpl applyLoanServiceImpl;
    
    
    @Test
    void testLoanDetails_InvalidResponse() {
        ApplyLoanDTO applyLoanDTO = new ApplyLoanDTO();
        String actual= applyLoanServiceImpl.loanDetails(applyLoanDTO);
        System.out.println(actual);
        String expect= "Missing";
        assertEquals(actual, expect);
    }

}
